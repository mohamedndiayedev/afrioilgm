
Hello {{Cookie::get('name')}},
Your account has successfully been created. Use your email address and the password <h2> {{Cookie::get('pwd')}} </h>to login to your account at the following link: http://127.0.0.1:8000/login