


<?php $__env->startSection("MainContent"); ?>

<!-- MODAL TO REMOVE USER  -->
  <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Remove User</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <h5 class="modal-h1" id="exampleModalLabel"></h5>
      <form action="" method="POST">
       <?php echo csrf_field(); ?>
          
       <input type="hidden" class="form-control" id="email" name="email">
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Confirm</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        
      </div></form>
    </div>
  </div>
</div> <!-- modal -->


<div class="container">
  <div class="v-tableDiv">

      <?php if(Session::get('page')=='customers'): ?>
        <table class="table" id="table">
          <thead>
            <tr>
              <th scope="col">Customer Name</th>
              <th scope="col">Email Address</th>
              <th scope="col">Contact</th>
              <th scope="col">Address</th>
            </tr>
          </thead>
          <tbody>

          <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($customer->name); ?></td>
              <td><?php echo e($customer->email); ?></td>
              <td><?php echo e($customer->contact); ?></td>
              <td><?php echo e($customer->address); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>


        <!-- if admins: -->
      <?php elseif(Session::get('page')=='admins'): ?>
        <table class="table" id="table">
          <thead>
            <tr>
              <th scope="col">Admin Name</th>
              <th scope="col">Email Address</th>
              <th scope="col">Action</th> 

            </tr>
          </thead>
          <tbody>

          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($user->name); ?></td>
              <td><?php echo e($user->email); ?></td>
              <td><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal" data-name=<?php echo $user->name; ?> data-email=<?php echo $user->email; ?>>Delete</button></td> 

            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>


        <!-- if staffs: -->
      <?php elseif(Session::get('page')=='staffs'): ?>
        <table class="table" id="table">
          <thead>
            <tr>
              <th scope="col">Staff Name</th>
              <th scope="col">Email Address</th>
              <th scope="col">Contact</th>
              <th scope="col">Branch</th>
              <th scope="col">Action</th> 

            </tr>
          </thead>
          <tbody>

          <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($staff->name); ?></td>
              <td><?php echo e($staff->email); ?></td>
              <td><?php echo e($staff->contact); ?></td>
              <td><?php echo e($staff->branch); ?></td>
              <td><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal" data-name=<?php echo $staff->name; ?> data-email=<?php echo $staff->email; ?>>Delete</button></td> 

            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>

      <?php endif; ?>

  </div>
</div><!-- .container -->

  <?php $__env->startSection('extraScripts'); ?>
    <!-- MODAL TO DELETE USER -->
    <script>
    $('#exampleModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var email = button.data('email') // Extract info from data-* attributes
    var name = button.data('name') // Extract info from data-* attributes

    var modal = $(this)
    modal.find('.modal-h1').text('Are you sure you want to remove the user ' + name + '?')
    document.getElementById("email").value = email;
    })
    </script>

    <script>
    $(document).ready( function () {
      $('#table').DataTable();
    } );</script>

  <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', [
  'pageTitle' => 'Manage Users',
  'iconSource' => 'images/coldoc.png',
  'pageSubTitle' => 'Master Voucher List Management'
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrioil\resources\views/manage-users.blade.php ENDPATH**/ ?>