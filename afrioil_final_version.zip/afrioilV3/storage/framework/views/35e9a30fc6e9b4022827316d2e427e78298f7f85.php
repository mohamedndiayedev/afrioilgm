


<?php $__env->startSection("MainContent"); ?>

<div class="container v-tableDiv">

<table class="table" id="table">
  <thead>
    <tr>
      <th scope="col">Serial Number</th>
      <th scope="col">Value</th>
      <th scope="col">Redeemed on</th>
      <th scope="col">Location</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php
$num = $voucher->id;
$str_length = 10;

$serial = substr("000000000{$num}", -$str_length);

?>
 
    <tr>
    <td><?php echo e($serial); ?></td>
      <td class="text-left"><?php echo e('D'.' '. $voucher->value); ?></td>
      <td class="text-left"><?php echo e($voucher->updated_at); ?></td>
      <td class="text-left"><?php echo e($voucher->location); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>


<script>
$(document).ready( function () {
    $('#table').DataTable();
} );

</script>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.customer', [
  'pageTitle' => 'Redeemed Vouchers',
  'iconSource' => 'images/coldoc.png',
  'pageSubTitle' => "List of Redeemed Vouchers"
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrioilV3\resources\views/customer-home.blade.php ENDPATH**/ ?>