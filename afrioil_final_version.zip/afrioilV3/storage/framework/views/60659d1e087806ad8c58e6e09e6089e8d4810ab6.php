


<?php $__env->startSection("MainContent"); ?>


  <div class="container">
    <div class="v-tableDiv">
      
      <form action="/create-master-voucher" method="POST">
          <?php echo csrf_field(); ?>
            <div class="col-md-8 mb-6 hello">  <span class="vform-icons"><img src="images/coupon.png" width="22" height="22"></span>
        <!-- <input type="text" class="vform-field" name="vname" placeholder="Voucher Name"></div> -->
        <select class='vform-field' name='vname'><option selected>Choose Voucher Name</option>
        <?php $names=Session::get('customerName');   ?>
        <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo $name; ?>"><?php echo e($name); ?></option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>

            <div class="col-md-8 mb-6">  <span class="vform-icons"><img src="images/code.png" width="19" height="19"></span>
        <input type="text" class="vform-field" name="scode" placeholder="Short Code"></div>


            <div class="col-md-8 mb-6">  <span class="vform-icons"><img src="images/sum.png" width="22" height="22"></span>
        <input type="number" class="vform-field" name="total" placeholder="Total Voucher" min="1"></div>


            <div class="col-md-8 mb-6">  <span class="vform-icons"><img src="images/$.png" width="22" height="22"></span>
            <select name="value" class="vform-field">
        <option selected>Choose Voucher Value</option>
                <option value="50">D 50</option>
                <option value="100">D 100</option>
                <option value="200">D 200</option>
              </select></div>

              <div class="col-md-8 mb-6">  <span class="vform-icons"><img src="images/timer.png" width="22" height="22"></span> Voucher Expiration Date:
        <input class="vform-field date-field" name="edate" type="date"></div>
        <div class="vbtn-div">
        <button type="submit" class="btn btn-secondary vform-btn">Create Master Voucher</button></form></div>

        </div>
        </form>
      </div>
    </div><!-- .container -->


    <?php $__env->startSection('extraScripts'); ?>
      <script>
        $(document).ready( function () {
          $('#table').DataTable();
        });
      </script>
    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', [
  'pageTitle' => 'Voucher',
  'iconSource' => 'images/colpenIcon.png',
  'pageSubTitle' => 'Create Vouchers'
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrioil\resources\views/create-master-voucher.blade.php ENDPATH**/ ?>