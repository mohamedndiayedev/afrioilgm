<?php if(Session::has('admin')): ?> 
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Landing Page</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/style.css" >
        <link href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" rel="stylesheet">

</head>

<body>
<img class="mainLogo" src="images/logo.png">
<div class="container master-div">
<div class="row">
<div class="col master-div2"><h1 class="master-h1">Customers</h1></div>
<div class="master-div3">
<?php echo $__env->make('includes.nav2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container master-div4">
    <div class="row">
<div class="col-1">   <img class="icon" src="images/colgroup.png" width="68" height="55"></div><div class="col-6"><h1 class="master-h2">Customers</h1><h2 class="master-h3">List of Customers</h2></div>
</div>
</div>

<div class=" master-div5"></div>
<div class="container v-tableDiv">
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Larry</td>
      <td>the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>
</div>
</div>
</div>
</div>
<footer>
<div class="container-fluid footerImg3 footerImg4"></div>   </footer>   


</body>
</html>

<?php else: ?>   

<script>
window.location = "/session-check";
</script>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\afrioil\resources\views/customers-list.blade.php ENDPATH**/ ?>