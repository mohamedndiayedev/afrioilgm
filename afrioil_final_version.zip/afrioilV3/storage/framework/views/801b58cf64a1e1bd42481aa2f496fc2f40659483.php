


<?php $__env->startSection("MainContent"); ?>

<div class="container v-tableDiv">

<table class="table">
  <thead>
    <tr>
      <th scope="col">Serial Number</th>
      <th scope="col">Voucher Name</th>
      <th scope="col">Value</th>
      <th scope="col">Expiry Date</th>
      <th scope="col">Redeemed on</th>
      <th scope="col">Staff</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php
$num = $voucher->id;
$str_length = 10;

$serial = substr("000000000{$num}", -$str_length);

?>
 
    <tr>
    <td><?php echo e($serial); ?></td>
      <td class="text-left"><?php echo e($voucher->voucher_name); ?></td>
      <td class="text-left"><?php echo e('D'.' '. $voucher->value); ?></td>
      <td class="text-left"><?php echo e($voucher->expiry_date); ?></td>
      <td class="text-left"><?php echo e($voucher->updated_at); ?></td>
      <td class="text-left"><?php echo e($voucher->staff); ?></td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>

</div>
</div>
</div>



<?php if(Session::has('redeem')): ?>
<div class="container flashbox">
<div class="col-md-7 offset-3 mt-4">
<p class="alert
<?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('redeem')); ?></p>
</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.staff', [
  'pageTitle' => 'Redeemed Vouchers',
  'iconSource' => 'images/coldoc.png',
  'pageSubTitle' => "List of Redeemed Vouchers for " . Session::get('location')
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrioil\resources\views/staff-home.blade.php ENDPATH**/ ?>