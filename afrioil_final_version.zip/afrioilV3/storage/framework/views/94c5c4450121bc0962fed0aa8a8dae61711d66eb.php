
Hello <?php echo e(Cookie::get('name')); ?>,
Your account has successfully been created. Use your email address and the password <h2> <?php echo e(Cookie::get('pwd')); ?> </h>to login to your account at the following link: http://127.0.0.1:8000/login<?php /**PATH C:\xampp\htdocs\afrioil\resources\views/emails/mail.blade.php ENDPATH**/ ?>