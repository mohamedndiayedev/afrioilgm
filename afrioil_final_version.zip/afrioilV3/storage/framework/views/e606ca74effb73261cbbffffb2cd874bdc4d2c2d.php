


<?php $__env->startSection("MainContent"); ?>

<div class="container">
    <div class="v-tableDiv">
      
      <table class="table" id="table">
      <thead>
        <tr>
          <th style="width: 90px;">Serial No.</th>
          <th style="width: 150px;">Voucher Name</th>
          <th>Value</th>
          <th style="width: 120px;">Expiry Date</th>
          <th style="width: 120px;">Generated on</th>
          <th>Status</th>
          <th>Download</th>

        </tr>
      </thead>
      <tbody>

        <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php

            $num = $voucher->id;
            $str_length = 10;
            $serial = substr("000000000{$num}", -$str_length);
          ?>
 
          <tr>
            <td><?php echo e($serial); ?></td>
            <td class="text-left"><?php echo e($voucher->voucher_name); ?></td>
            <td class="text-center"><?php echo e('D'.' '. $voucher->value); ?></td>
            <td class="text-center"><?php echo e($voucher->expiry_date); ?></td>
            <td class="text-center"><?php echo e(date('Y-m-d', strtotime($voucher->created_at))); ?></td>
            
            <?php if($voucher->status == 'Valid'): ?>

            <td class="text-center"><button class="btn btn-success"><?php echo e($voucher->status); ?></button></td>

            <?php else: ?>  

            <td class="text-center"><?php echo e($voucher->status); ?></td>

            <?php endif; ?>

            <td class="text-center">
              <div onclick="location.href='/individual?id=<?php echo $voucher->id; ?>';" style="cursor: pointer;">
                <img src="images/download.png" width="20" height="20">
              </div>
            </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
      </div>
    </div><!-- .container -->

<script>
$(document).ready( function () {
    $('#table').DataTable();
} );

</script>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.customer', [
  'pageTitle' => 'Vouchers',
  'iconSource' => 'images/coldoc.png',
  'pageSubTitle' => "List of all Vouchers"
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\afrioilV3\resources\views/customer-vouchers.blade.php ENDPATH**/ ?>